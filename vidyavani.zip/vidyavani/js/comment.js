function submitComment() {
    // Get the comment from the textarea
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var website = document.getElementById('website').value;
    var message = document.getElementById('message').value;

    // Basic validation
    if (name.trim() === '') {
        alert('Please enter a name');
        return;
    }

    if (email.trim() === '') {
        alert('Please enter an email');
        return;
    }

    if (message.trim() === '') {
        alert('Please enter a message');
        return;
    }

    // Create a new comment element with Bootstrap classes
    var commentElement = document.createElement('div');
    commentElement.className = 'media mb-4';

    var imgElement = document.createElement('img');
    imgElement.src = 'img/user.jpg'; // You can replace this with the actual path to the user image
    imgElement.alt = 'Image';
    imgElement.className = 'img-fluid mr-3 mt-1';
    imgElement.style.width = '45px';

    var mediaBodyElement = document.createElement('div');
    mediaBodyElement.className = 'media-body';

    var h6Element = document.createElement('h6');
    h6Element.innerHTML = '<a href="#">' + username + '</a> <small><i>01 Jan 2045</i></small>';

    var pElement = document.createElement('p');
    pElement.textContent = commentText;

    var buttonElement = document.createElement('button');
    buttonElement.className = 'btn btn-sm btn-outline-secondary';
    buttonElement.textContent = 'Reply';

    // Append elements to the comment container
    mediaBodyElement.appendChild(h6Element);
    mediaBodyElement.appendChild(pElement);
    mediaBodyElement.appendChild(buttonElement);

    commentElement.appendChild(imgElement);
    commentElement.appendChild(mediaBodyElement);

    // Append the new comment to the comments section
    document.getElementById('comments').appendChild(commentElement);

    // Clear the input fields for the next comment
    document.getElementById('username').value = '';
    document.getElementById('comment').value = '';
}
