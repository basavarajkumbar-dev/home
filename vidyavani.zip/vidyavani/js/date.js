// Get the current date and time
var currentDate = new Date();
    
// Format the date and time (e.g., "December 10, 2023 12:30:45")
var formattedDate = currentDate.toLocaleString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'});

// Display the formatted date and time in the specified element
document.getElementById('currentDateTime').innerHTML = formattedDate;